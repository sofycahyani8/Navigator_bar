package com.example.flutter_navigator_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

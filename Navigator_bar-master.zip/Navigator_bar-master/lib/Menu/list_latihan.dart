import 'package:flutter/material.dart';

class ListLatihan {
  String id, title, subtitle;
  ListLatihan({required this.id, required this.title, required this.subtitle});
}